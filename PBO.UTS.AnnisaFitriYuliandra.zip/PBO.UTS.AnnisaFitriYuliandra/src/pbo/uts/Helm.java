package pbo.uts;
public class Helm {
    public String merkHelm;
    public String size;
    public String symbolHelm;
    public String warnaHelm;
    public Helm(String merkHelm, String size, String symbolHelm, String warnaHelm){
        this.merkHelm = merkHelm;
        this.size = size;
        this.symbolHelm = symbolHelm;
        this.warnaHelm = warnaHelm;
    }
    public void setMerkHelm(String merkHelm){
        this.merkHelm = merkHelm;
    }
    public String getMerkHelm(){
        return merkHelm;
    }
    public void setSize(String size){
        this.size = size;
    }
    public String getSize(){
        return size;
    }
    public void setSymbolHelm(String symbolHelm){
        this.symbolHelm = symbolHelm;
    }
    public String getSymbolHelm(){
        return symbolHelm;
    }
    public void setWarnaHelm(String warnaHelm){
        this.warnaHelm = warnaHelm;
    }
    public String getWarnaHelm(){
        return warnaHelm;
    }
    public void tampilHelm(){
        System.out.println("Merk Helm     : "+getMerkHelm());
        System.out.println("Size          : "+getSize());
        System.out.println("Symbol Helm   : "+getSymbolHelm());
        System.out.println("Warna Helm    : "+getWarnaHelm());
    }
}
