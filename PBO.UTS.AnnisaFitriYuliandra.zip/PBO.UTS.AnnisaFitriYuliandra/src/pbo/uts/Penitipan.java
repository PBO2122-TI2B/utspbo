package pbo.uts;
public class Penitipan {
    public Helm helmMotor;
    public HelmFullFace fullFace;
    public HelmModular modular;
    public DataPenitipan anggota;
    public Penitipan(DataPenitipan anggota, Helm helmMotor){
        this.anggota = anggota;
        this.helmMotor = helmMotor;
    }
    public Penitipan(DataPenitipan anggota, HelmFullFace fullFace){
        this.anggota = anggota;
        this.fullFace = fullFace;
    }
    public Penitipan(DataPenitipan anggota, HelmModular modular){
        this.anggota = anggota;
        this.modular = modular;
    }
    public void TampilDataUmum(){
        System.out.println("\n        PENITIPAN HELM");
        anggota.tampilData();
        helmMotor.tampilHelm();
    }
    public void TampilDataFullFace(){
        System.out.println("\n        PENITIPAN HELM");
        anggota.tampilData();
        fullFace.tampilHelmFullFace();
    }
    public void TampilDataModular(){
        System.out.println("\n        PENITIPAN HELM");
        anggota.tampilData();
        modular.tampilHelmModular();
    }
}
