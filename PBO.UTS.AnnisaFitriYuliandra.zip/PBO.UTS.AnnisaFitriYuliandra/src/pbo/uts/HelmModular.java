package pbo.uts;
public class HelmModular extends Helm{
    public String security;
    public HelmModular(String merkHelm, String size, String symbolHelm, String warnaHelm, String security){
        super(merkHelm, size, symbolHelm, warnaHelm);
        this.security = security;
    }
    public void setSecurity(String security){
        this.security = security;
    }
    public String getSecurity(){
        return security;
    }
    public void tampilHelmModular(){
        super.tampilHelm();
        System.out.println("Keamanan      : "+security);
    }
}
