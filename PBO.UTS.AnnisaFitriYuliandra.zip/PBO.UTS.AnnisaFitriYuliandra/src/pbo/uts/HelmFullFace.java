package pbo.uts;
public class HelmFullFace extends Helm{
    public String standarBalap;
    public HelmFullFace(String merkHelm, String size, String symbolHelm, String warnaHelm, String standarBalap){
        super(merkHelm, size, symbolHelm, warnaHelm);
        this.standarBalap = standarBalap;
    }
    public void setStandarBalap(String standarBalap){
        this.standarBalap = standarBalap;
    }
    public String getStandarBalap(){
        return standarBalap;
    }
    public void tampilHelmFullFace(){
        super.tampilHelm();
        System.out.println("Standar Balap : "+standarBalap);
    }
}
