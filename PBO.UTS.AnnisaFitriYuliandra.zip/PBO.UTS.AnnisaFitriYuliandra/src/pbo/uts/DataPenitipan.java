package pbo.uts;
public class DataPenitipan {
    public String nama;
    public String alamat;
    public String jenisKelamin;
    public DataPenitipan(String nama, String alamat, String jenisKelamin){
        this.nama = nama;
        this.alamat = alamat;
        this.jenisKelamin = jenisKelamin;
    }
    public void setNama(String nama){
        this.nama = nama;
    }
    public String getNama(){
        return nama;
    }
    public void setAlamat(String alamat){
        this.alamat = alamat;
    }
    public String getAlamat(){
        return alamat;
    }
    public void setJenisKelamin(String jenisKelamin){
        this.jenisKelamin = jenisKelamin;
    }
    public String getJenisKelamin(){
        return jenisKelamin;
    }
    public void tampilData(){
        System.out.println("Nama          : "+getNama());
        System.out.println("Alamat        : "+getAlamat());
        System.out.println("Gender        : "+getJenisKelamin());
    }
}
