package pbo.uts;
public class Main {
    public static void main(String[] args) {
        DataPenitipan a1 = new DataPenitipan("Rangga","Jl.Suropati No.4","Men");
        Helm h1 = new Helm("NHK","L","SNI","White");
        Penitipan p1 = new Penitipan(a1, h1);
        p1.TampilDataUmum();
        DataPenitipan a2 = new DataPenitipan("Mustasfa","Jl.Diponegoro No.18","Men");
        HelmFullFace h2 = new HelmFullFace("Helmet","XL","SNI","Black", "FIM");
        Penitipan p2 = new Penitipan(a2, h2);
        p2.TampilDataFullFace();
        DataPenitipan a3 = new DataPenitipan("Vian","Jl.Arjuno No.11","Men");
        HelmModular h3 = new HelmModular("HBC","L","SNI","Red","Approved");
        Penitipan p3 = new Penitipan(a3, h3);
        p3.TampilDataModular();
    } 
}
